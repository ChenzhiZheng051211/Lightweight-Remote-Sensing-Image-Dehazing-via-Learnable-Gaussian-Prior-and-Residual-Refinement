"""Public Ours entry; frozen model arithmetic is imported without rewriting."""
from pathlib import Path
import sys,json,hashlib
import torch
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'frozen_runtime'))
from rs_v26_capacity_batch import create_v26_capacity
def sha256(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def build_model(config=None):
    """Create the97704-parameter architecture; the unfitted RBF head needs TRAIN initialization."""
    cfg=json.loads((HERE/'configs/model.json').read_text('utf8')) if config is None else dict(config)
    return create_v26_capacity(cfg)
def verify_frozen_sources():
    sources=json.loads((HERE/'provenance/frozen_source_sha256.json').read_text('utf8'))
    for name,sha in sources.items():
        if sha256(HERE/name)!=sha:raise ValueError('Frozen scientific source changed: '+name)
def load_pretrained(dataset='satehaze1k',device='cpu',verify_sources=True):
    weights=json.loads((HERE/'provenance/weights.json').read_text('utf8'))
    if dataset not in weights:raise ValueError('Unknown dataset: '+dataset)
    row=weights[dataset];p=HERE/row['file']
    if sha256(p)!=row['SHA256']:raise ValueError('Packaged exact weight SHA256 differs')
    if verify_sources:verify_frozen_sources()
    # These files are our SHA-bound trusted original exact exports, with metadata.
    payload=torch.load(p,map_location='cpu',weights_only=False)
    model=build_model(payload['metadata']['model_config']);model.load_state_dict(payload['model'],strict=True)
    if sum(p.numel() for p in model.parameters())!=97704 or not bool(model._head_initialized):raise ValueError('Wrong model/head')
    return model.to(device).eval()
