"""Dispatch a new user-requested training run to the exact original trainer."""
from pathlib import Path
import sys,argparse,subprocess
HERE=Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dataset',choices=['rsid','satehaze1k','rrshid','dhid'],required=True);p.add_argument('--data-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--device',default='cuda:0');p.add_argument('--config',type=Path);p.add_argument('--train-manifest',type=Path);p.add_argument('--val-manifest',type=Path);p.add_argument('--resume',action='store_true');p.add_argument('--profile-steps',type=int,default=0);a=p.parse_args()
    runtime=HERE/('frozen_runtime_dhid' if a.dataset=='dhid' else 'frozen_runtime');config=a.config or HERE/'configs'/('train_'+a.dataset+'.json');tr=a.train_manifest or HERE/'manifests'/a.dataset/'train.json';va=a.val_manifest or HERE/'manifests'/a.dataset/'val.json'
    cmd=[sys.executable,'-B',str(runtime/'train_repair.py'),'--data-root',str(a.data_root.resolve()),'--output',str(a.output.resolve()),'--config',str(config.resolve()),'--train-manifest',str(tr.resolve()),'--val-manifest',str(va.resolve()),'--device',a.device,'--profile-steps',str(a.profile_steps)]
    if a.resume:cmd.append('--resume')
    subprocess.run(cmd,cwd=runtime,check=True)
if __name__=='__main__':main()
