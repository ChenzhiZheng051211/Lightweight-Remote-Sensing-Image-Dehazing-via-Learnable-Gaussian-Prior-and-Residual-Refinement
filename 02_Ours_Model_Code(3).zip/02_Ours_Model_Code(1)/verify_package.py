"""Finite CPU-only functional checks on synthetic inputs, not TEST evaluation."""
from pathlib import Path
import json,argparse,sys,platform,importlib.metadata
import torch
from model import HERE,load_pretrained,verify_frozen_sources
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,default=Path('verification.json'));a=p.parse_args();torch.set_num_threads(2);verify_frozen_sources()
    from rs_v26_capacity_runtime import load_localgate_checkpoint
    x=torch.rand((1,3,128,128),generator=torch.Generator().manual_seed(20260910));rows=[]
    for ds in ['rsid','satehaze1k','rrshid','dhid']:
        m=load_pretrained(ds,'cpu');original,_=load_localgate_checkpoint(HERE/'weights'/(ds+'.pt'),'cpu')
        with torch.inference_mode():y=m(x);ref=original(x)
        assert sum(z.numel() for z in m.parameters())==97704 and y['mean'].shape==(1,3,128,128) and y['pixel_variance'].shape==(1,1,128,128)
        assert set(y)==set(ref)
        for key in sorted(y):
            assert torch.isfinite(y[key]).all() and torch.equal(y[key],ref[key])
        assert (y['pixel_variance']>0).all()
        rows.append({'dataset':ds,'parameters':97704,'model_state_tensors':len(m.state_dict()),'strictload':True,'CPU128_forward_finite_positive_variance':True,'all_output_tensors_equal_original_loader':True,'maximum_error':0.0,'output_tensors_checked':sorted(y)})
    d={'Python':platform.python_version(),'torch':torch.__version__,'CPU_only':True,'input':'seeded synthetic128 RGB; no dataset/GT','four_exact_weights':rows,'training_backward_optimizer_full_TEST_GPU_calls':0};a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(d,indent=2),'utf8');print(json.dumps(d))
if __name__=='__main__':main()
