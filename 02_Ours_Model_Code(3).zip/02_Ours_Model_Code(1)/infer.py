"""Single-image inference; no GT, crop, resizing, tiling, or test-time augmentation."""
import argparse
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from model import load_pretrained
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--dataset',choices=['rsid','satehaze1k','rrshid','dhid'],default='satehaze1k');p.add_argument('--input',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--variance-output',type=Path);p.add_argument('--device',default='cpu');a=p.parse_args()
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    model=load_pretrained(a.dataset,a.device);x=np.asarray(Image.open(a.input).convert('RGB'),dtype=np.float32)/255;x=torch.from_numpy(x.copy()).permute(2,0,1)[None].to(a.device)
    with torch.inference_mode():pred=model(x)
    rgb=pred['mean'][0].float().clamp(0,1).cpu().permute(1,2,0).numpy();a.output.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(np.rint(rgb*255).astype(np.uint8)).save(a.output)
    if a.variance_output:
        a.variance_output.parent.mkdir(parents=True,exist_ok=True);np.save(a.variance_output,pred['pixel_variance'][0].float().cpu().permute(1,2,0).numpy(),allow_pickle=False)
    print('Saved native RGB:',a.output)
if __name__=='__main__':main()
